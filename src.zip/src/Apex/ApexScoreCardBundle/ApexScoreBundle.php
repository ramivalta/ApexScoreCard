<?php

namespace Apex\ApexScoreCardBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ApexScoreBundle extends Bundle
{
}
